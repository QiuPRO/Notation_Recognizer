#pragma once

#include "Note.h"
#include <vector>

using std::vector;

class Group
{
public:
	Group(Note &note) { notes.push_back(note); }
	~Group();
	vector<Note> notes;
private:
	
};

