#pragma once

#include <QThread>
#include "Group.h"

class PlayThread : public QThread
{
	Q_OBJECT
public:
	// ctors and dtors
	explicit PlayThread(vector<Group> &_sheet, QObject *parent = 0);
	~PlayThread();

	void setPlaying(bool flag) { playing = flag; }
	// set the playing configures: 
	//		HPM: Hemidemisemiquaver(��ʮ�ķ�����) per minite, 
	//      instrument: instrument to use, 
	//		moveKey: numbers of keys to move. Positive to up and negative to down.
	void setPlayConf(int DPM, int instrument, int moveKey);

protected:
	void run();

private:
	vector<Group> &sheet;
	bool playing;
	int HPM, instrument, moveKey;

signals:
	void isDone();  //��������ź�

signals:

public slots:
};
