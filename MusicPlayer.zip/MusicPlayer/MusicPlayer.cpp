#include "MusicPlayer.h"

MusicPlayer::MusicPlayer(QWidget *parent)
    : QMainWindow(parent)
{
	// set window size
	setFixedSize(800, 600);
	// initialize buttons
	btnPlay = new QPushButton(this);
	btnPlay->setText("Play");
	btnPlay->move(200, 100);
	btnStop = new QPushButton(this);
	btnStop->setText("Stop");
	btnStop->move(400, 100);
	btnSelect = new QPushButton(this);
	btnSelect->setText("Select");
	btnSelect->move(500, 450);
	connect(btnPlay, SIGNAL(clicked()), this, SLOT(clickPlay()));
	connect(btnStop, SIGNAL(clicked()), this, SLOT(clickStop()));
	connect(btnSelect, SIGNAL(clicked()), this, SLOT(clickSelect()));
	// intialize spinboxes
	boxMoveKey = new QSpinBox(this);
	boxMoveKey->move(300, 300);
	boxMoveKey->setPrefix("Rise/Fall: ");
	boxMoveKey->setMaximum(12);
	boxMoveKey->setMinimum(-12);
	boxBPM = new QSpinBox(this);
	boxBPM->move(500, 300);
	boxBPM->setPrefix("Beats per minite: ");
	boxBPM->setMaximum(240);
	boxBPM->setMinimum(60);
	boxBPM->setValue(120);
	// initialize filename lineedit
	lineFilename = new QLineEdit(this);
	lineFilename->move(350, 450);
	lineFilename->setFocusPolicy(Qt::NoFocus);
	lineFilename->setText("No file.");
	// play the initial music
	sheet.sheet.push_back(Group(Note(ToneName::A, ToneGroup::SG, 24)));
	sheet.sheet.push_back(Group(Note(ToneName::G, ToneGroup::SG, 8)));
	sheet.sheet.push_back(Group(Note(ToneName::E, ToneGroup::SG, 16)));
	sheet.sheet.push_back(Group(Note(ToneName::D, ToneGroup::SG, 16)));
	sheet.sheet.push_back(Group(Note(ToneName::C, ToneGroup::SG, 4)));
	QMediaPlayer *player = new QMediaPlayer();
	player->setMedia(QUrl::fromLocalFile("music/piano/C5.mp3"));
	player->setVolume(50); //0~100������Χ,Ĭ����100
	player->play();
	QThread::sleep(1);
	clickPlay();
}

void MusicPlayer::clickPlay()
{
	sheet.play(boxMoveKey->value(), boxBPM->value());
}

void MusicPlayer::clickStop()
{
	sheet.stop();
}

void MusicPlayer::clickSelect()
{
	QString filename = QFileDialog::getOpenFileName(this, tr("choose a sheetmusic"), "", tr("SheetMusic (*.sht)"));
	lineFilename->setText(filename);
	if(sheet.readFromFile(filename))
		QMessageBox::information(this, "Info", "Success!");
	else
		QMessageBox::warning(this, "Info", "Failed!");
}