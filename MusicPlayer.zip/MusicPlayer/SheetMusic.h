#pragma once
#include "Group.h"
#include "PlayThread.h"
#include <qfile.h>
#include <qtextstream.h>

class SheetMusic
{
public:
	SheetMusic();
	~SheetMusic();
	void play(int move, int BPM);
	void stop();
	bool readFromFile(QString filename);
	int tune() const { return m_tune; }
	int BPM() const { return m_BPM; }
	std::pair<int, int> timeSig() const { return m_timeSig; }

	vector<Group> sheet;

private:
	PlayThread *thread;
	int m_tune;
	int m_BPM;
	std::pair<int, int> m_timeSig;
	int barCnt;

	const int keys[8] = { 0, 2, 4, 5, 7, 9, 11, 12 };

	bool readHead(QString head);
	Group *readGroup(QString group);
};

