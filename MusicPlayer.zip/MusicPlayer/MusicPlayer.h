#pragma once

#include <QtWidgets/QMainWindow>
#include "SheetMusic.h"
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qfiledialog.h>
#include <qlineedit.h>
#include <qmessagebox.h>

class MusicPlayer : public QMainWindow
{
    Q_OBJECT

public:
    MusicPlayer(QWidget *parent = Q_NULLPTR);

private:
	SheetMusic sheet;

	QPushButton *btnPlay, *btnStop, *btnSelect;
	QSpinBox *boxMoveKey;
	QSpinBox *boxBPM;
	QLineEdit *lineFilename;

public slots:
	void clickPlay();
	void clickStop();
	void clickSelect();
};
