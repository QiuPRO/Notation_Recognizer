#include "PlayThread.h"



PlayThread::PlayThread(vector<Group> &_sheet, QObject *parent) : sheet(_sheet)
{
	HPM = 1920;
	instrument = 0;
	moveKey = 0;
}


PlayThread::~PlayThread()
{
}

void PlayThread::setPlayConf(int HPM, int instrument, int moveKey)
{
	this->HPM = HPM;
	this->instrument = instrument;
	this->moveKey = moveKey;
}

void PlayThread::run()
{
	playing = true;
	int n = sheet.size();
	for (int i = 0; i < n; i++)
	{
		int m = sheet[i].notes.size();
		for (int j = 0; j < m; j++)
		{
			if (!playing) return;
			sheet[i].notes[j].play(HPM, instrument, moveKey);
		}
	}
	emit isDone();  //��������ź�
	playing = false;
}