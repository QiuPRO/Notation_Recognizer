#include "Note.h"

QMediaPlayer* Note::players[90];
constexpr char* Note::toneName[12];

Note::Note(ToneName name, ToneGroup group, int _len) : tone(name, group), len(_len) {
	if (players[0] != nullptr)
		return;
	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			int id = calPlayerId(i, j);
			if (id < 0 || id >= 88)
				continue;
			if (players[id] == nullptr)
			{
				players[id] = new QMediaPlayer();
				players[id]->setMedia(QUrl::fromLocalFile("music/piano/" + calFilename(i, j) + ".mp3"));
				players[id]->setVolume(50); //0~100������Χ,Ĭ����100
			}
		}
	}
}

Note::~Note()
{
	//delete player;
}

#include <iostream>

void Note::play(int HPM, int instrument, int moveKey)
{
	// check if it is an empty note
	if (tone.name == ToneName::Empty)
	{
		long t = 60000000.0 / HPM * len;
		QThread::usleep(t);
		return;
	}
	// calculate the key to play
	int name = (int)tone.name + moveKey;
	int group = (int)tone.group;
	if (name >= 12)
	{
		name -= 12;
		group += 1;
	}
	if (name < 0)
	{
		name += 12;
		group -= 1;
	}
	std::cout << name;
	// find the corresponding player
	int id = calPlayerId(name, group);
	if (id < 0 || id >= 88)
		return;
	players[id]->stop();
	players[id]->play();
	// wait
	long t = 60000000.0 / HPM * len;
	std::cout << ": " << t << std::endl;
	QThread::usleep(t);
}

int Note::calPlayerId(int name, int group)
{
	return group * 12 + name - 5;
}

QString Note::calFilename(int name, int group)
{
	QString res = toneName[name];
	res += QString::number(group);
	return res;
}

void Note::move(int bias)
{
	int name = (int)tone.name + bias;
	int group = (int)tone.group;
	if (name >= 12)
	{
		name -= 12;
		group += 1;
	}
	if (name < 0)
	{
		name += 12;
		group -= 1;
	}
	tone.name = (ToneName)name;
	tone.group = (ToneGroup)group;
}
