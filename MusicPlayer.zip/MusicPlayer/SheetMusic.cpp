#include "SheetMusic.h"


SheetMusic::SheetMusic()
{
	thread = new PlayThread(sheet, thread);
	barCnt = 0;
}


SheetMusic::~SheetMusic()
{
}

void SheetMusic::play(int move, int BPM)
{
	thread->setPlayConf(BPM * 16, 0, move);
	thread->start();
}

void SheetMusic::stop()
{
	thread->setPlaying(false);
}

bool SheetMusic::readFromFile(QString filename)
{
	Group *group;
	// open the file
	QFile file(filename);
	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
		return false;
	QTextStream in(&file);
	// create a new vector to store. If the file is correct finally, then overwrite the origin sheet
	vector<Group> list;
	// read the sheet head
	QString line = in.readLine();
	if (!readHead(line)) return false;
	// read the sheet body
	line = in.readLine();
	while (!line.isNull()) {
		QStringList groups = line.split(" ");
		for (int i = 0; i < groups.size(); i++)
		{
			group = readGroup(groups[i]);
			if (group)
				list.push_back(*group);
		}
		line = in.readLine();
	}
	// overwrite the origin sheet
	sheet = list;
	return true;
}

bool SheetMusic::readHead(QString head)
{
	QStringList list = head.split(" ");
	bool ok;
	// check if the elements are enough
	if (list.size() != 4)
		return false;
	// check if the tune is valid. If so, set it
	for (m_tune = 0; m_tune < 12; m_tune++)
		if (list[0] == Note::toneName[m_tune])
			break;
	if (m_tune == 12)
		return false;
	// read the time signiture
	int i1 = list[1].toInt(&ok, 10);
	if (!ok || i1 == 0) return false;
	int i2 = list[2].toInt(&ok, 10);
	if (!ok || i2 == 0) return false;
	m_timeSig = std::pair<int, int>(i1, i2);
	// read the beats per minute
	i1 = list[3].toInt(&ok, 10);
	if (!ok) return false;
	m_BPM = i1;
	return true;
}

Group *SheetMusic::readGroup(QString group)
{
	// transform the QString to char*
	QByteArray ba = group.toLatin1();
	char *str = ba.data();
	// declare vars
	ToneName name;
	ToneGroup gr;
	int len = 16;
	int i = 0;
	// check if it is a bar seperation
	if (str[0] == '|')
	{
		barCnt++;
		return nullptr;
	}
	// read the key name
	name = ToneName(keys[str[i++] - '1']);
	if (str[i + 1] == '#')
		name = ToneName(int(name) + 1);
	else if (str[i + 1] == 'b')
		name = ToneName(int(name) - 1);
	else
		i--;
	i++;
	// read the key group
	gr = ToneGroup(str[i++] - '0');
	// read the length
	while (str[i] != 0)
	{
		if (str[i] == '_')
			len /= 2;
		else if (str[i] == '.')
			len = len * 3 / 2;
		else if (str[i] == '-')
			len += 16;
		i++;
	}
	// create note object
	Note *note = new Note(name, gr, len);
	note->setBarNum(barCnt);
	// set to the correct key
	note->move(m_tune);
	// return the result
	Group *res = new Group(*note);
	return res;
}
