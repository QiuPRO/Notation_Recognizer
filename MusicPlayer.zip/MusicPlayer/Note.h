#pragma once
#include <qmediaplayer.h>
#include <qthread.h>

enum class ToneName {
	C, Cs, D, Ds, E, F, Fs, G, Gs, A, As, B, Empty
};

enum class ToneGroup {
	LG2, LG1, LG,
	SG, SG1, SG2, SG3, SG4, SG5
};

class Tone
{
public:
	Tone(ToneName _name, ToneGroup _group) { name = _name; group = _group; }
//private:
	ToneName name;
	ToneGroup group;
};

class Note
{
public:
	Note(ToneName name, ToneGroup group, int _len);
	~Note();
	static constexpr char* toneName[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
	void play(int DPM, int instrument, int moveKey);
	int calPlayerId(int name, int group);
	QString calFilename(int name, int group);
	void move(int bias);
	void setBarNum(int num) { m_barNum = num; }
	int barNum() const { return m_barNum; }

private:
	//std::shared_ptr<QMediaPlayer> player;
	
	static QMediaPlayer* players[90];
	Tone tone;
	int len;
	int m_barNum;
};

